package quiz;

public interface Quizable {
	
	public void createQuiz(QuestionRepository repository) ;
		
	
}
